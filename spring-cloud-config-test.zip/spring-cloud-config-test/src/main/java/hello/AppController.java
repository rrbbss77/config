package hello;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RefreshScope
@RestController
public class AppController {

    @Autowired
    private AppProp appProp;
    
    @Value("${app.name}")
    private String appName;

    
    
    @RequestMapping("/config")
    public String config() {
    	
    	return "Current Config Value::: " + appProp.getName() + 
    			"</br> Current Address:: " + appProp.getAddress() + 
    			"</br> Direct value name:: " + this.appName;
    }
    
    
    
}
