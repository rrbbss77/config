package hello;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

@RefreshScope
@Component
@ConfigurationProperties(prefix="app")
public class AppProp {
	
	private String name;
	private String address;

	public String getName() {
		return name;
	}

	public void setName(String prop1) {
		this.name = prop1;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	

}
